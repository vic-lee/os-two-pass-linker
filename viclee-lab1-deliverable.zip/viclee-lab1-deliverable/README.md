# Lab 1: Two-Pass Linker

## Getting started

From the project directory, run `python3 main.py` to compile and run the program, then paste your input on the console. 