# Lab 1: Two-Pass Linker

## Getting started

From the project directory, run `python3 src/main.py < req/input-x`. x (1-9) specifies the input file tested. 
