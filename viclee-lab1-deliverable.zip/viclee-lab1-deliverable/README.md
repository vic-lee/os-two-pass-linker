# Lab 1: Two-Pass Linker

## Getting started

From the project directory, follow the instructions below to run the program:

1. `python3 main.py`
2. Paste in your input
3. If the cursor is not on a new line after entering input, type `ENTER`
4. Enter `Ctrl-D` to exit input mode, program output should then be printed out
